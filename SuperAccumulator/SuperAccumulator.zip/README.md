# SuperAccumulator
1
超级蓄电池，1E的电量，足以用到游戏结束；
总电量：1000*1000*1000*1000*1000*1000；
最大输入输出：     1000*1000*1000*1000;
假如用完了，拆掉再放一个就行了；

2
拆除进背包的是满电。


## Installation

1. Install BepInEx
2. Then drag .dll into BepInEx/plugins


 

## 安装

1. 先安装 BepInEx框架
2. 拖 .dll 到BepInEx/plugins文件夹内
