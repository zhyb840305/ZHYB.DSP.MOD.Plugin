# AutoFixStationByReciper
在物流塔上添加一个选择配方的按钮，通过配方对物流塔进行搭配

## Installation

1. Install BepInEx
2. Then drag AutoFixStationByReciper.dll into BepInEx/plugins


# 自动配置物流塔内容

1 在物流塔上添加一个“选择配方”的按钮；
2 点击选择配方；
3 自动对物流塔进行配置； 

## 安装

1. 先安装 BepInEx框架
2. 拖 AutoFixStationByReciper.dll 到BepInEx/plugins文件夹内
