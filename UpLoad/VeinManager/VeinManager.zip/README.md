# **VeinManager**
　　矿物控制：对矿物自动整理.
　　《全矿物添加》模式，《全矿物添加》模式后，添加全部矿物，每样矿物3000万份
　　因为一个星球可能仅用一次，快捷键设置：Ctrl Alt Shift V
　　
---
　　
**联系QQ：232748974**
　　
------------
　　
　　
# **Installation**
　　1.Install BepInEx
　　2.Then drag .dll into BepInEx/plugins
　　
------------
　　
　　
# **安装**
　　1.先安装 BepInEx框架
　　2.拖 .dll 到BepInEx/plugins文件夹内