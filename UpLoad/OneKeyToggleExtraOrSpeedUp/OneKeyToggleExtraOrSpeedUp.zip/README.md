# OneKeyToggleExtraOrSpeedUp
	
	一键将本星球所有设备的《增产效果》切换 “加速模式/增产模式”
	因为一个星球可能仅用一次，快捷键设置：Ctrl+Alt+Shift+L　　
---
# **联系QQ：232748974**
[gitHub](https://github.com/zhyb840305/ZHYB.DSP.MOD.Plugin)

---
# **更新说明**
	V20230508.22.55
		第一版，估计是最终版
	
---
　　
　　
# **Installation**
	1.Install BepInEx
	2.Then drag .dll into BepInEx/plugins
　　
------------
　　
　　
# **安装**
	1.先安装 BepInEx框架
	2.拖 .dll 到BepInEx/plugins文件夹内