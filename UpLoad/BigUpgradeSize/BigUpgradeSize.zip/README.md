# BigUpgradeSize
	
	更大的升级范围，默认是10×10；本Mod设置成20×20；　
---
# **联系QQ：232748974**
[gitHub](https://github.com/zhyb840305/ZHYB.DSP.MOD.Plugin)

---
# **更新说明**
	V20230516.15.38
		第一版，估计是最终版
	
---
　　
　　
# **Installation**
	1.Install BepInEx
	2.Then drag .dll into BepInEx/plugins
　　
------------
　　
　　
# **安装**
	1.先安装 BepInEx框架
	2.拖 .dll 到BepInEx/plugins文件夹内